import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useDispatch, useSelector } from 'react-redux';
import { fetchConfig } from '../redux/slices/configSlice';
import AdminLayout from '../components/adminLayout'; 

const BACKEND_URL = 'http://localhost:3000';
const API_URL = `${BACKEND_URL}/api`;

const MusicManagerPage = () => {
  const dispatch = useDispatch();
  const { data: configData, isLoading } = useSelector((state) => state.config);
  
  const [selectedFile, setSelectedFile] = useState(null);
  const [previewUrl, setPreviewUrl] = useState('');
  const [isUploading, setIsUploading] = useState(false);

  useEffect(() => {
    dispatch(fetchConfig());
  }, [dispatch]);

  // Handle saat user memilih file dari komputer
  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      if (!file.type.startsWith('audio/')) {
        alert('Harap pilih file audio (MP3, WAV, dsb)!');
        return;
      }
      setSelectedFile(file);
      // Buat URL sementara agar lagu bisa didengarkan sebelum diupload
      setPreviewUrl(URL.createObjectURL(file)); 
    }
  };

  // Fungsi Eksekusi Upload ke Server
  const handleUploadMusic = async (e) => {
    e.preventDefault();
    if (!selectedFile) return alert('Silakan pilih file lagu terlebih dahulu!');
    
    setIsUploading(true);

    // Pakai FormData karena kita mengirim file fisik, bukan teks JSON biasa
    const formData = new FormData();
    formData.append('musicFile', selectedFile);

    try {
      await axios.post(`${API_URL}/admin/config/music`, formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });
      
      alert('Musik latar berhasil diunggah!');
      setSelectedFile(null);
      setPreviewUrl('');
      dispatch(fetchConfig()); // Refresh data dari server
    } catch (error) {
      console.log("Gagal upload musik:", error);
      alert(error.response?.data?.message || 'Terjadi kesalahan saat mengunggah musik latar.');
    } finally {
      setIsUploading(false);
    }
  };

  // Fungsi Helper untuk render URL audio dari server lokal
  const getAudioSource = () => {
    const dbUrl = configData?.config?.bgmUrl;
    if (dbUrl) {
      // Jika nyangkut di /uploads/, pastikan ditambah domain backend localhost:5000
      return dbUrl.startsWith('/uploads/') ? `${BACKEND_URL}${dbUrl}` : dbUrl;
    }
    return '';
  };

  return (
    <AdminLayout title="Manajemen Musik">
      <div className="max-w-3xl mx-auto">
        
        <div className="mb-6">
          <h2 className="text-2xl font-bold text-gray-800">Pengaturan Musik Latar</h2>
          <p className="text-gray-500 mt-1">Unggah lagu berformat MP3 yang akan diputar otomatis pada undangan.</p>
        </div>

        {isLoading ? (
          <div className="text-center py-10 text-gray-500">Memuat pengaturan...</div>
        ) : (
          <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
            
            {/* AREA MUSIK YANG SEDANG AKTIF (TERSIMPAN DI DATABASE) */}
            <div className="bg-purple-50 p-6 border-b border-purple-100 flex flex-col items-center text-center">
              <h3 className="font-semibold text-purple-900 mb-4">Musik Undangan Saat Ini</h3>
              {getAudioSource() ? (
                <audio 
                  controls 
                  src={getAudioSource()} 
                  className="w-full max-w-md outline-none"
                  controlsList="nodownload"
                >
                  Browser Anda tidak mendukung elemen audio.
                </audio>
              ) : (
                <p className="text-sm text-purple-600 italic">Belum ada musik yang diunggah.</p>
              )}
            </div>

            {/* FORM UPLOAD MUSIK BARU */}
            <div className="p-6">
              <form onSubmit={handleUploadMusic}>
                <div className="mb-6">
                  <label className="block text-sm font-medium text-gray-700 mb-3">
                    Pilih File Musik Baru
                  </label>
                  
                  <div className="border-2 border-dashed border-gray-300 rounded-xl p-6 text-center bg-gray-50 hover:bg-gray-100 transition cursor-pointer relative">
                    <input 
                      type="file" 
                      accept="audio/*"
                      onChange={handleFileChange}
                      className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                    />
                    <div className="text-gray-500">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 mx-auto mb-2 text-purple-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3" />
                      </svg>
                      {selectedFile ? (
                        <span className="font-medium text-purple-600">{selectedFile.name}</span>
                      ) : (
                        <span>Klik atau seret file MP3 ke area ini</span>
                      )}
                    </div>
                  </div>
                </div>

                {/* AREA PREVIEW SEBELUM UPLOAD */}
                {previewUrl && (
                  <div className="mb-6 bg-yellow-50 p-4 rounded-xl border border-yellow-200">
                    <p className="text-xs text-yellow-800 font-medium mb-2 uppercase tracking-wide">Dengarkan Preview Sebelum Upload:</p>
                    <audio controls src={previewUrl} className="w-full h-10"></audio>
                  </div>
                )}

                <div className="flex justify-end border-t pt-4">
                  <button 
                    type="submit" 
                    disabled={isUploading || !selectedFile}
                    className="bg-purple-600 text-white px-8 py-3 rounded-xl font-medium hover:bg-purple-700 transition flex items-center gap-2 shadow-lg shadow-purple-200 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {isUploading ? (
                      'Mengunggah...'
                    ) : (
                      <>
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
                        </svg>
                        Upload Musik
                      </>
                    )}
                  </button>
                </div>
              </form>
            </div>

          </div>
        )}
      </div>
    </AdminLayout>
  );
};

export default MusicManagerPage;