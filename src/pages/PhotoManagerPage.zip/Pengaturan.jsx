import { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchConfig, updateConfig } from '../redux/slices/configSlice';
import AdminLayout from '../components/adminLayout';

const Pengaturan = () => {
  const dispatch = useDispatch();
  const { data, isLoading, isUpdating } = useSelector((state) => state.config);

  const [formData, setFormData] = useState({
    bride: { name: '', father: '', mother: '', address: '' },
    groom: { name: '', father: '', mother: '', address: '' },
    events: [{ name: '', date: '', time: '', location: '' }],
    otherFamily: [{ name: '' }],
    mapsLink: '',
    eventDate: '',
    bankAccounts: [{ bank: '', account: '', name: '' }]
  });

  useEffect(() => {
    dispatch(fetchConfig());
  }, [dispatch]);

  useEffect(() => {
    if (data) {
      const formattedDate = data.eventDate ? new Date(data.eventDate).toISOString().slice(0, 16) : '';
      
      setFormData({
        bride: data.bride || { name: '', father: '', mother: '', address: '', instagram: '' },
        otherFamily: data.otherFamily && data.otherFamily.length > 0 ? data.otherFamily : [{ name: '' }],
        groom: data.groom || { name: '', father: '', mother: '', address: '', instagram: '' },
        mapsLink: data.mapsLink || '',
        eventDate: formattedDate,
        events: data.events && data.events.length > 0 ? data.events : [{ name: '', date: '', time: '', location: '' }],
        bankAccounts: data.bankAccounts && data.bankAccounts.length > 0 
          ? data.bankAccounts 
          : [{ bank: '', account: '', name: '' }]
      });
    }
  }, [data]);

  // Handle input biasa (Event Date & Maps)
  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  // Handle input bertingkat (Bride & Groom)
  const handleNestedChange = (person, field, value) => {
    setFormData({
      ...formData,
      [person]: {
        ...formData[person],
        [field]: value
      }
    });
  };

  // FIX: Handle Family Change (Turut Mengundang)
  const handleFamilyChange = (index, field, value) => {
    const newFamily = [...formData.otherFamily];
    newFamily[index] = { ...newFamily[index], [field]: value };
    setFormData({ ...formData, otherFamily: newFamily });
  };

  const addOtherFamily = () => {
    setFormData({
      ...formData,
      otherFamily: [...formData.otherFamily, { name: '' }]
    });
  };

  const removeFamily = (index) => {
    setFormData({ ...formData, otherFamily: formData.otherFamily.filter((_, i) => i !== index) });
  };

  // FIX: Handle Bank Accounts Change
  const handleBankChange = (index, field, value) => {
    const newBankAccounts = [...formData.bankAccounts];
    newBankAccounts[index] = { ...newBankAccounts[index], [field]: value };
    setFormData({ ...formData, bankAccounts: newBankAccounts });
  };

  const addBankAccount = () => {
    setFormData({ ...formData, bankAccounts: [...formData.bankAccounts, { bank: '', account: '', name: '' }] });
  };

  const removeBankAccount = (index) => {
    const newBankAccounts = formData.bankAccounts.filter((_, i) => i !== index);
    setFormData({ ...formData, bankAccounts: newBankAccounts });
  };

  // FIX: Handle Event Change
  const handleEventChange = (index, field, value) => {
    const newEvents = [...formData.events];
    newEvents[index] = { ...newEvents[index], [field]: value };
    setFormData({ ...formData, events: newEvents });
  };

  const addEvent = () => {
    setFormData({ ...formData, events: [...formData.events, { name: '', date: '', time: '', location: '' }] });
  };

  const removeEvent = (index) => {
    setFormData({ ...formData, events: formData.events.filter((_, i) => i !== index) });
  };

  const handleSaveConfig = () => {
    dispatch(updateConfig(formData));
    alert('Data acara berhasil disimpan!');
  };

  return (
    <AdminLayout title="Pengaturan">
      <div className="max-w-4xl mx-auto space-y-8 pb-10">
        
        {isLoading ? (
          <p className="text-gray-500 text-center py-10">Memuat data...</p>
        ) : (
          <>
            {/* KARTU 1: DATA MEMPELAI WANITA */}
            <div className="bg-white p-8 rounded-xl border border-rose-100 shadow-sm border-t-4 border-t-rose-400">
              <h3 className="text-lg font-bold text-gray-800 mb-6">Data Mempelai Wanita</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-2">Nama Lengkap</label>
                  <input type="text" value={formData.bride.name} onChange={(e) => handleNestedChange('bride', 'name', e.target.value)} className="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-rose-200" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Nama Bapak</label>
                  <input type="text" value={formData.bride.father} onChange={(e) => handleNestedChange('bride', 'father', e.target.value)} className="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-rose-200" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Nama Ibu</label>
                  <input type="text" value={formData.bride.mother} onChange={(e) => handleNestedChange('bride', 'mother', e.target.value)} className="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-rose-200" />
                </div>
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-2">Alamat Domisili</label>
                  <textarea rows="2" value={formData.bride.address} onChange={(e) => handleNestedChange('bride', 'address', e.target.value)} className="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-rose-200"></textarea>
                </div>
              </div>
            </div>

            {/* KARTU 2: DATA MEMPELAI PRIA */}
            <div className="bg-white p-8 rounded-xl border border-blue-100 shadow-sm border-t-4 border-t-blue-400">
              <h3 className="text-lg font-bold text-gray-800 mb-6">Data Mempelai Pria</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-2">Nama Lengkap</label>
                  <input type="text" value={formData.groom.name} onChange={(e) => handleNestedChange('groom', 'name', e.target.value)} className="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-200" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Nama Bapak</label>
                  <input type="text" value={formData.groom.father} onChange={(e) => handleNestedChange('groom', 'father', e.target.value)} className="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-200" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Nama Ibu</label>
                  <input type="text" value={formData.groom.mother} onChange={(e) => handleNestedChange('groom', 'mother', e.target.value)} className="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-200" />
                </div>
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-2">Alamat Domisili</label>
                  <textarea rows="2" value={formData.groom.address} onChange={(e) => handleNestedChange('groom', 'address', e.target.value)} className="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-200"></textarea>
                </div>
              </div>
            </div>

            {/* KARTU 5: TURUT MENGUNDANG */}
            <div className="bg-white p-8 rounded-xl border border-green-100 shadow-sm border-t-4 border-t-green-400">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-lg font-bold text-gray-800">Keluarga Besar (Turut Mengundang)</h3>
                <button
                  type="button"
                  onClick={addOtherFamily}
                  className="text-sm bg-green-100 text-green-700 px-4 py-2 rounded-lg font-medium"
                >Tambah Keluarga</button>
              </div>
              <div className="space-y-3">
                {formData.otherFamily.map((family, index) => (
                  <div key={index} className="flex gap-3 items-center">
                    <input 
                      type="text"
                      value={family.name}
                      onChange={(e) => handleFamilyChange(index, 'name', e.target.value)}
                      placeholder="Contoh: Keluarga Besar Bapak Ahmad"
                      className="flex-1 px-4 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-green-200"
                    />
                    <button 
                      type="button"
                      onClick={() => removeFamily(index)}
                      className="text-red-500 p-2 hover:bg-red-100 rounded text-sm font-medium"
                    >
                      Hapus
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* KARTU 3: JADWAL & LOKASI */}
            <div className="bg-white p-8 rounded-xl border border-gray-100 shadow-sm">
              <h3 className="text-lg font-bold text-gray-800 mb-6">Jadwal & Lokasi Acara Utama</h3>
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Tanggal & Waktu Countdown</label>
                  <input type="datetime-local" name="eventDate" value={formData.eventDate} onChange={handleChange} className="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-purple-200" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Link Google Maps</label>
                  <input type="text" name="mapsLink" placeholder="https://goo.gl/maps/..." value={formData.mapsLink} onChange={handleChange} className="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-purple-200" />
                </div>
              </div>
            </div>

            {/* KARTU 4: REKENING HADIAH */}
            <div className="bg-white p-8 rounded-xl border border-gray-100 shadow-sm">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-lg font-bold text-gray-800">Rekening Hadiah</h3>
                <button type="button" onClick={addBankAccount} className="text-sm bg-purple-100 text-purple-700 px-4 py-2 rounded-lg font-medium">
                  + Tambah
                </button>
              </div>
              <div className="space-y-4">
                {formData.bankAccounts.map((bank, index) => (
                  <div key={index} className="flex flex-col md:flex-row gap-4 items-end bg-gray-50 p-4 rounded-lg border border-gray-200">
                    <div className="flex-1 w-full"><label className="text-xs mb-1 block text-gray-500">Bank</label><input type="text" value={bank.bank} onChange={(e) => handleBankChange(index, 'bank', e.target.value)} className="w-full p-2 border rounded" /></div>
                    <div className="flex-1 w-full"><label className="text-xs mb-1 block text-gray-500">No Rek</label><input type="text" value={bank.account} onChange={(e) => handleBankChange(index, 'account', e.target.value)} className="w-full p-2 border rounded" /></div>
                    <div className="flex-1 w-full"><label className="text-xs mb-1 block text-gray-500">Atas Nama</label><input type="text" value={bank.name} onChange={(e) => handleBankChange(index, 'name', e.target.value)} className="w-full p-2 border rounded" /></div>
                    {formData.bankAccounts.length > 1 && (
                      <button type="button" onClick={() => removeBankAccount(index)} className="text-red-500 p-2 hover:bg-red-100 rounded">Hapus</button>
                    )}
                  </div>
                ))}
              </div>
            </div>
            
            {/* DAFTAR KEGIATAN */}
            <div className='bg-white p-8 rounded-xl border border-gray-100 shadow-sm'>
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-lg font-bold text-gray-800">Daftar Kegiatan (Akad, Resepsi, dll)</h3>
                <button type="button" onClick={addEvent} className="text-sm bg-purple-100 text-purple-700 px-4 py-2 rounded-lg font-medium">
                  + Tambah
                </button>
              </div>
              <div className="space-y-4">
                {formData.events.map((event, index) => (
                  <div key={index} className="flex flex-col md:flex-row gap-4 items-end bg-gray-50 p-4 rounded-lg border border-gray-200">
                    <div className="flex-1 w-full"><label className="text-xs mb-1 block text-gray-500">Nama Acara</label><input type="text" value={event.name} onChange={(e) => handleEventChange(index, 'name', e.target.value)} className="w-full p-2 border rounded" /></div>
                    <div className="flex-1 w-full"><label className="text-xs mb-1 block text-gray-500">Tanggal</label><input type="date" value={event.date} onChange={(e) => handleEventChange(index, 'date', e.target.value)} className="w-full p-2 border rounded" /></div>
                    <div className="flex-1 w-full"><label className="text-xs mb-1 block text-gray-500">Waktu</label><input type="time" value={event.time} onChange={(e) => handleEventChange(index, 'time', e.target.value)} className="w-full p-2 border rounded" /></div>
                    <div className="flex-1 w-full"><label className="text-xs mb-1 block text-gray-500">Lokasi</label><input type="text" value={event.location} onChange={(e) => handleEventChange(index, 'location', e.target.value)} className="w-full p-2 border rounded" /></div>
                    {formData.events.length > 1 && (
                      <button type="button" onClick={() => removeEvent(index)} className="text-red-500 p-2 hover:bg-red-100 rounded">Hapus</button>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* TOMBOL SIMPAN UTAMA */}
            <div className="flex justify-end pt-4">
              <button onClick={handleSaveConfig} disabled={isUpdating} className="bg-purple-600 text-white px-8 py-3 rounded-lg font-bold hover:bg-purple-700 shadow-md transition-colors">
                {isUpdating ? 'Menyimpan...' : 'Simpan Semua Pengaturan'}
              </button>
            </div>
          </>
        )}
      </div>
    </AdminLayout>
  );
};

export default Pengaturan;