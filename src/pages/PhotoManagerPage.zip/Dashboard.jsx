import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchGuests, addGuest, deleteGuest } from '../redux/slices/guestSlice';
import AdminLayout from '../components/adminLayout';

// Template Default Bawaan Sistem
const DEFAULT_TEMPLATE = `Bismillahirrohmanirrohim.

Tanpa mengurangi rasa hormat, perkenankan kami mengundang Bapak/Ibu/Saudara/i *[NAMA_TAMU]* untuk hadir di acara pernikahan kami.

Detail acara dan konfirmasi kehadiran dapat diakses melalui tautan berikut:
[LINK_UNDANGAN]

Merupakan suatu kehormatan dan kebahagiaan bagi kami apabila Bapak/Ibu/Saudara/i berkenan hadir memberikan doa restu.

Terima kasih.`;

const Dashboard = () => {
  const dispatch = useDispatch();
  const { data: guests, isLoading, isAdding } = useSelector((state) => state.guest);
  
  const [showForm, setShowForm] = useState(false);
  const [newGuestName, setNewGuestName] = useState('');

  // --- STATE UNTUK TEMPLATE MASTER WA ---
  const [showTemplateEditor, setShowTemplateEditor] = useState(false);
  const [globalTemplate, setGlobalTemplate] = useState(DEFAULT_TEMPLATE);

  // --- STATE UNTUK MODAL KIRIM WHATSAPP (POP-UP FINAL) ---
  const [isWaModalOpen, setIsWaModalOpen] = useState(false);
  const [waMessage, setWaMessage] = useState('');
  const [currentGuestWa, setCurrentGuestWa] = useState(null);

  // ==========================================
  // INITIAL LOAD (AMBIL DATA & TEMPLATE LOKAL)
  // ==========================================
  useEffect(() => {
    dispatch(fetchGuests());
    
    // Cek apakah user pernah menyimpan template custom di localStorage
    const savedTemplate = localStorage.getItem('waTemplate');
    if (savedTemplate) {
      setGlobalTemplate(savedTemplate);
    }
  }, [dispatch]);

  // Handle submit form tambah tamu
  const handleAddGuest = (e) => {
    e.preventDefault();
    if (!newGuestName.trim()) return;
    
    dispatch(addGuest({ guestName: newGuestName })).then((res) => {
      if (!res.error) {
        setNewGuestName('');
        setShowForm(false);
      } else {
        alert(res.payload); 
      }
    });
  };

  // Simpan Template WA ke Local Storage
  const handleSaveTemplate = () => {
    localStorage.setItem('waTemplate', globalTemplate);
    alert('Template WhatsApp Master berhasil disimpan!');
    setShowTemplateEditor(false);
  };

  // Kalkulasi Statistik Otomatis
  const totalGuests = guests.length;
  const attending = guests.filter(g => g.isAttending === true).length;
  const notAttending = guests.filter(g => g.isAttending === false && g.message !== undefined).length; 
  const pending = totalGuests - attending - notAttending;

  // Fungsi untuk copy link undangan
  const copyLink = (slug) => {
    const url = `${window.location.origin}/?to=${slug}`;
    navigator.clipboard.writeText(url);
    alert('Link undangan disalin!\n' + url);
  };

  // ==========================================
  // FUNGSI MEMBUKA MODAL WHATSAPP
  // ==========================================
  const openWaModal = (guest) => {
    const url = `${window.location.origin}/?to=${guest.slug}`;
    
    // REPLACE variabel [NAMA_TAMU] dan [LINK_UNDANGAN] dengan data asli tamu
    const finalMessage = globalTemplate
      .replace(/\[NAMA_TAMU\]/g, guest.guestName)
      .replace(/\[LINK_UNDANGAN\]/g, url);

    setWaMessage(finalMessage);
    setCurrentGuestWa(guest);
    setIsWaModalOpen(true); // Buka pop up final
  };

  // ==========================================
  // FUNGSI EKSEKUSI KIRIM WHATSAPP
  // ==========================================
  const handleSendWa = () => {
    if (!waMessage.trim()) {
      alert('Pesan tidak boleh kosong!');
      return;
    }
    const encodedMessage = encodeURIComponent(waMessage);
    window.open(`https://wa.me/?text=${encodedMessage}`, '_blank');
    setIsWaModalOpen(false); 
  };

  return (
    <AdminLayout title="Daftar Tamu">
      
      {/* ========================================= */}
      {/* MODAL POP-UP FINAL SEBELUM KIRIM WHATSAPP */}
      {/* ========================================= */}
      {isWaModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
          <div className="bg-white rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden">
            <div className="bg-green-500 p-4 text-white flex justify-between items-center">
              <h3 className="font-bold flex items-center gap-2">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                </svg>
                Preview Pesan
              </h3>
              <button onClick={() => setIsWaModalOpen(false)} className="text-white hover:text-green-200">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
              </button>
            </div>
            <div className="p-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">Edit tambahan sebelum dikirim (opsional):</label>
              <textarea 
                rows="8"
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 text-sm"
                value={waMessage}
                onChange={(e) => setWaMessage(e.target.value)}
              ></textarea>
            </div>
            <div className="bg-gray-50 px-6 py-4 flex justify-end gap-3 border-t">
              <button onClick={() => setIsWaModalOpen(false)} className="px-5 py-2 rounded-lg text-gray-600 font-medium hover:bg-gray-200 transition">
                Batal
              </button>
              <button onClick={handleSendWa} className="px-5 py-2 bg-green-500 text-white rounded-lg font-medium hover:bg-green-600 transition flex items-center gap-2">
                Kirim WA Sekarang
              </button>
            </div>
          </div>
        </div>
      )}

      {/* KARTU STATISTIK */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        <div className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm">
          <p className="text-sm text-gray-500 font-medium">Total Undangan</p>
          <h3 className="text-2xl font-bold mt-2">{totalGuests}</h3>
        </div>
        <div className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm">
          <p className="text-sm text-gray-500 font-medium">Hadir</p>
          <h3 className="text-2xl font-bold text-green-600 mt-2">{attending}</h3>
        </div>
        <div className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm">
          <p className="text-sm text-gray-500 font-medium">Tidak Hadir</p>
          <h3 className="text-2xl font-bold text-red-500 mt-2">{notAttending}</h3>
        </div>
        <div className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm">
          <p className="text-sm text-gray-500 font-medium">Belum Respon</p>
          <h3 className="text-2xl font-bold text-yellow-500 mt-2">{pending}</h3>
        </div>
      </div>

      {/* HEADER & TOMBOL AKSI */}
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-bold text-gray-800">Daftar RSVP</h3>
        <div className="flex gap-2">
          {/* Tombol Edit Template WA */}
          <button 
            onClick={() => {
              setShowTemplateEditor(!showTemplateEditor);
              setShowForm(false);
            }}
            className="bg-white border border-gray-300 text-gray-700 px-5 py-2.5 rounded-full text-sm font-medium hover:bg-gray-50 transition shadow-sm flex items-center gap-2"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-green-500" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
            Edit Template WA
          </button>
          
          <button 
            onClick={() => {
              setShowForm(!showForm);
              setShowTemplateEditor(false);
            }}
            className="bg-gray-900 text-white px-5 py-2.5 rounded-full text-sm font-medium hover:bg-gray-800 transition shadow-sm"
          >
            {showForm ? 'Batal Tambah' : '+ Tambah Tamu'}
          </button>
        </div>
      </div>

      {/* ========================================= */}
      {/* AREA EDITOR TEMPLATE MASTER WA */}
      {/* ========================================= */}
      {showTemplateEditor && (
        <div className="bg-green-50 p-6 rounded-xl border border-green-200 mb-6">
          <div className="mb-4">
            <h4 className="font-bold text-green-900">Pengaturan Template Master WhatsApp</h4>
            <p className="text-sm text-green-700 mt-1">Gunakan <strong>[NAMA_TAMU]</strong> untuk otomatis menyisipkan nama tamu, dan <strong>[LINK_UNDANGAN]</strong> untuk menyisipkan link unik mereka.</p>
          </div>
          <textarea 
            rows="7"
            className="w-full px-4 py-3 border border-green-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 text-sm mb-3 shadow-inner"
            value={globalTemplate}
            onChange={(e) => setGlobalTemplate(e.target.value)}
          ></textarea>
          <div className="flex justify-end gap-3">
            <button 
              onClick={() => setGlobalTemplate(DEFAULT_TEMPLATE)}
              className="text-sm text-gray-500 hover:text-gray-700 underline"
            >
              Kembalikan ke Default
            </button>
            <button 
              onClick={handleSaveTemplate}
              className="bg-green-600 text-white px-6 py-2 rounded-lg font-medium hover:bg-green-700"
            >
              Simpan Template
            </button>
          </div>
        </div>
      )}

      {/* FORM TAMBAH TAMU */}
      {showForm && (
        <div className="bg-purple-50 p-6 rounded-xl border border-purple-100 mb-6">
          <form onSubmit={handleAddGuest} className="flex gap-4 items-end">
            <div className="flex-1">
              <label className="block text-sm font-medium text-purple-900 mb-2">Nama Tamu Baru</label>
              <input 
                type="text" 
                autoFocus
                placeholder="Contoh: Keluarga Budi Santoso" 
                value={newGuestName}
                onChange={(e) => setNewGuestName(e.target.value)}
                className="w-full px-4 py-2 border border-purple-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-400"
              />
            </div>
            <button type="submit" disabled={isAdding} className="bg-purple-600 text-white px-6 py-2 rounded-lg font-medium hover:bg-purple-700 disabled:opacity-50">
              {isAdding ? 'Menyimpan...' : 'Simpan'}
            </button>
          </form>
        </div>
      )}

      {/* AREA TABEL */}
      <div className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
        {isLoading ? (
          <div className="p-12 text-center text-gray-400">Memuat data tamu...</div>
        ) : guests.length === 0 ? (
          <div className="p-12 text-center text-gray-400">Belum ada tamu yang ditambahkan.</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse min-w-[800px]">
              <thead>
                <tr className="bg-gray-50 border-b border-gray-100 text-sm text-gray-500">
                  <th className="p-4 font-medium">Nama Tamu</th>
                  <th className="p-4 font-medium">Link & Bagikan</th>
                  <th className="p-4 font-medium text-center">Status Kehadiran</th>
                  <th className="p-4 font-medium text-center">Jumlah Orang</th>
                  <th className="p-4 font-medium">Pesan</th>
                  <th className="p-4 font-medium text-center">Aksi</th>
                </tr>
              </thead>
              <tbody>
                {guests.map((guest) => (
                  <tr key={guest._id} className="border-b border-gray-50 hover:bg-gray-50/50 transition">
                    <td className="p-4 font-medium text-gray-800">{guest.guestName}</td>
                    
                    {/* KOLOM LINK DAN WHATSAPP */}
                    <td className="p-4">
                      <div className="flex flex-col gap-2">
                        <button 
                          onClick={() => copyLink(guest.slug)}
                          className="text-purple-600 text-sm hover:underline flex items-center gap-1.5 w-fit"
                        >
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
                          </svg>
                          Copy Link
                        </button>
                        
                        <button 
                          onClick={() => openWaModal(guest)}
                          className="text-green-600 text-sm hover:underline flex items-center gap-1.5 w-fit font-medium"
                        >
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                          </svg>
                          Kirim via WA
                        </button>
                      </div>
                    </td>
                    
                    <td className="p-4 text-center">
                      {guest.message ? (
                         guest.isAttending 
                         ? <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-xs font-semibold">Hadir</span>
                         : <span className="bg-red-100 text-red-700 px-3 py-1 rounded-full text-xs font-semibold">Tidak Hadir</span>
                      ) : (
                        <span className="bg-yellow-100 text-yellow-700 px-3 py-1 rounded-full text-xs font-semibold">Pending</span>
                      )}
                    </td>
                    <td className="p-4 text-center font-medium text-gray-600">{guest.headcount > 0 ? guest.headcount : '-'}</td>
                    <td className="p-4 text-sm text-gray-600 italic">
                      {guest.message || "Belum ada pesan."}
                    </td>
                    <td className="p-4 text-center">
                      <button 
                        onClick={() => {
                          if (window.confirm(`Yakin ingin menghapus tamu ${guest.guestName}?`)) {
                            dispatch(deleteGuest(guest._id));
                          }
                        }}
                        className="text-red-600 hover:text-red-800 transition-colors p-2"
                        title="Hapus Tamu"
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                        </svg>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

    </AdminLayout>
  );
};

export default Dashboard;